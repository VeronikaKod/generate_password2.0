
from random import *
from tkinter import * 
from tkinter import messagebox 

window = Tk()
window.title("Генератор паролей")
window.geometry("900x900")
number = "1234567890"
letters = "qwertyuiopasdfghjklzxcvbnm"
up_letters = letters.upper()
spec = "./,':;[]'()"

def password():
    global number, letters , up_letters, spec, suda
    peremennaia = ""
    if var.get() == 1:
        peremennaia += number
    if var1.get() == 1:
        peremennaia += letters
    if var2.get() == 1:
        peremennaia += up_letters        
    if var3.get() == 1:
        peremennaia += spec  

    if variant.get() == 1:
        b = 6
    elif variant.get() == 2:
        b = 10
    elif variant.get() == 3:
        b = 16
    else:
        messagebox.showwarning("ОбШиБка", "Вы чево, вы обшибка")
        return

    a = 0
    suda = ""

    while a < b:
        a += 1
        suda += choice(peremennaia)
    lab.config(text=f"Ваш пароль {suda}")
    list.insert(END, suda)
    
def copy_password():
    window.clipboard_clear()
    window.clipboard_append(suda)
    messagebox.showinfo("Ура", "Скопировано")

lab = Label(window, text="Выбирайте из чего будет состоять ваш пароль")
lab.pack()

var = IntVar()
check = Checkbutton(window, text="цифры",variable= var)
check.pack()

var1 = IntVar()
check = Checkbutton(window, text="строчные буквы", variable= var1)
check.pack()

var2 = IntVar()
check = Checkbutton(window, text="заглавные буквы",variable= var2)
check.pack()

var3 = IntVar()
check = Checkbutton(window, text="спецсимволы",variable= var3)
check.pack()


lab1 = Label(window, text="Длинна символов")
lab1.pack()

# enter = Entry(window)
# enter.pack()

variant = IntVar()
che = Radiobutton(window, text="6 символов", variable=variant, value= 1)
che.pack()
che1 = Radiobutton(window, text="10 символов", variable=variant, value= 2)
che1.pack()
che2 = Radiobutton(window, text="16 символов", variable=variant, value= 3)
che2.pack()

But = Button(window, text="Сгенерировать", command=password)
But.pack()

list = Listbox(window)
list.pack()

But1 = Button(window, text="Скопировать", command=copy_password)
But1.pack()

window.mainloop()